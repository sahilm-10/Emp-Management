package com.example.employeemanagementapis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
